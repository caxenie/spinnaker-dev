#pragma GCC diagnostic ignored "-Wwrite-strings"

extern "C"
{
  #include <spin1_api.h>
}