#pragma GCC diagnostic ignored "-Wwrite-strings"

extern "C"
{
  #include <sark.h>
}